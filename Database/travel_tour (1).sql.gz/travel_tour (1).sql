-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2024 at 11:44 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `travel_tour`
--

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `image_id` varchar(200) NOT NULL,
  `image_main` varchar(255) DEFAULT NULL,
  `sub_image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`image_id`, `image_main`, `sub_image`) VALUES
('0', 'pic.jpg', NULL),
('1zAhJCik5MxJTXB', '', NULL),
('ABOpcx50v0cSJBk', 'pic-test.jpg', NULL),
('bEK5BEZqPiS8USk', 'pic-test.jpg', NULL),
('ERF1ViJN02Y70pJ', 'pic-test.jpg', NULL),
('kAUEhtaIrRjTLvt', 'can_tho.jpg', NULL),
('l5udlM3jfgTaW61', 'pic-test.jpg', NULL),
('o8DQqJpBhjOxcO4', 'Neon Sunset, Axiom Design.jpg', NULL),
('tJiM7UcSAJAfjsQ', 'pic-test.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderId` varchar(255) NOT NULL,
  `tourId` varchar(255) DEFAULT NULL,
  `price` double NOT NULL,
  `totalPrice` double NOT NULL,
  `name_user_order` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `create_by` varchar(200) NOT NULL,
  `time_book` date DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderId`, `tourId`, `price`, `totalPrice`, `name_user_order`, `address`, `phone`, `create_by`, `time_book`) VALUES
('order0001', '7RiDW5ryjuCnddF', 90, 90, 'Nguyen Van A', 'Address 1', '0900000001', 'User1', '2024-03-01'),
('order0002', 'asdflsjdlfs', 100, 200, 'Nguyen Van B', 'Address 2', '0900000002', 'User2', '2024-03-05'),
('order0003', 'asldfjlsdjf', 110, 330, 'Nguyen Van C', 'Address 3', '0900000003', 'User3', '2024-03-10'),
('order0005', 'ksadflsjdjlf', 80, 400, 'Nguyen Van E', 'Address 5', '0900000005', 'User5', '2024-03-20'),
('order0006', 'sdfkalskdjjflk', 90, 540, 'Nguyen Van F', 'Address 6', '0900000006', 'User6', '2024-03-25'),
('order0008', '7RiDW5ryjuCnddF', 110, 220, 'Nguyen Van H', 'Address 8', '0900000008', 'User8', '2024-04-05'),
('order0009', 'asdflsjdlfs', 120, 360, 'Nguyen Van I', 'Address 9', '0900000009', 'User9', '2024-04-10'),
('order0010', 'asldfjlsdjf', 80, 320, 'Nguyen Van J', 'Address 10', '0900000010', 'User10', '2024-04-15'),
('order0012', 'ksadflsjdjlf', 100, 600, 'Nguyen Van L', 'Address 12', '0900000012', 'User12', '2024-04-25'),
('order0013', 'sdfkalskdjjflk', 110, 110, 'Nguyen Van M', 'Address 13', '0900000013', 'User13', '2024-05-01'),
('order0015', '7RiDW5ryjuCnddF', 80, 240, 'Nguyen Van O', 'Address 15', '0900000015', 'User15', '2024-05-10'),
('order0016', 'asdflsjdlfs', 90, 360, 'Nguyen Van P', 'Address 16', '0900000016', 'User16', '2024-05-15'),
('SvOy4aJmmpWDFTZ', '7RiDW5ryjuCnddF', 100, 100, 'nguyen  van vv', 'tp   ho chi  mminh', '1222321223', 'tran duong', '2024-05-18');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `paymentId` varchar(200) NOT NULL,
  `userid` varchar(200) DEFAULT NULL,
  `orderId` varchar(200) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `time_payment` date DEFAULT current_timestamp(),
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`paymentId`, `userid`, `orderId`, `quantity`, `time_payment`, `price`) VALUES
('0xFA2sQejyHgo5i', 'mIsm30479hp9PNF', 'gSBW0Bwz9NKtVbi', 1, '2024-05-18', 100),
('2KEknvae0ikfRPN', 'FBDZWx8jPkuPHN7', 'SvOy4aJmmpWDFTZ', 1, '2024-05-18', 100),
('6E57Q9qXfKBu5VD', 'fFZ3oWe16x9o6t4', 'z3onpYibGxOPULZ', 10, '2024-05-19', 100),
('payment0001', 'User1', 'order0001', 1, '2024-03-01', 90),
('payment0002', 'User2', 'order0002', 2, '2024-03-05', 100),
('payment0003', 'User3', 'order0003', 3, '2024-03-10', 110),
('payment0005', 'User5', 'order0005', 5, '2024-03-20', 80),
('payment0006', 'User6', 'order0006', 6, '2024-03-25', 90),
('payment0008', 'User8', 'order0008', 2, '2024-04-05', 110),
('payment0009', 'User9', 'order0009', 3, '2024-04-10', 120),
('payment0010', 'User10', 'order0010', 4, '2024-04-15', 80),
('payment0012', 'User12', 'order0012', 6, '2024-04-25', 100),
('payment0013', 'User13', 'order0013', 1, '2024-05-01', 110),
('payment0015', 'User15', 'order0015', 3, '2024-05-10', 80),
('payment0016', 'User16', 'order0016', 4, '2024-05-15', 90);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `rolesId` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`rolesId`, `name`, `status`) VALUES
('role1', 'all', '1');

-- --------------------------------------------------------

--
-- Table structure for table `time_book_details`
--

CREATE TABLE `time_book_details` (
  `time_id` varchar(255) DEFAULT NULL,
  `tuor_id` varchar(255) DEFAULT NULL,
  `start_time` varchar(255) DEFAULT NULL,
  `end_time` varchar(255) DEFAULT NULL,
  `is_payment` varchar(255) DEFAULT NULL,
  `is_deleted` varchar(255) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  `update_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tours`
--

CREATE TABLE `tours` (
  `tour_id` varchar(200) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `price_one_person` double DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `image_id` varchar(50) DEFAULT NULL,
  `destination_description` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `time_book_start` date DEFAULT current_timestamp(),
  `time_book_end` date DEFAULT NULL,
  `create_by` varchar(50) DEFAULT NULL,
  `create_at` date DEFAULT current_timestamp(),
  `update_at` date DEFAULT NULL,
  `expense` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tours`
--

INSERT INTO `tours` (`tour_id`, `title`, `price_one_person`, `quantity`, `image_id`, `destination_description`, `address`, `time_book_start`, `time_book_end`, `create_by`, `create_at`, `update_at`, `expense`) VALUES
('7RiDW5ryjuCnddF', 'tour   them moi 1', 100, 1, 'o8DQqJpBhjOxcO4', 'hoa cai do', 'hai  phong', '2024-04-16', '2024-04-16', NULL, '2024-04-22', NULL, 80),
('asdflsjdlfs', 'Tour Phiêu Lưu Đà Lạt', 120, 10, '0', 'Tham gia vào các hoạt động mạo hiểm ở Đà Lạt.', 'Đà Lạt, Lâm Đồng', '2024-04-22', '2024-04-22', 'admin', '2024-04-17', '2024-04-17', 0),
('asldfjlsdjf', 'Trải Nghiệm Di Sản Huế', 90, 0, '0', 'Khám phá lịch sử và văn hóa phong phú của Huế.', 'Huế, Thừa Thiên-Huế', '2024-04-23', '2024-04-23', 'admin', '2024-04-17', '2024-04-17', 0),
('asldfjlsdjj', 'Khám Phá Thiên Nhiên Quảng Ninh', 110, 0, '0', 'Khám phá những kỳ quan thiên nhiên của tỉnh Quảng Ninh.', 'Quảng Ninh, Việt Nam', '2024-04-24', '2024-04-24', 'admin', '2024-04-17', '2024-04-17', 0),
('ewjrmldfjsldfls', 'vịnh hạ long', 1000, 0, '1', 'template', 'quảng ninh', '2024-04-06', NULL, 'root', '2024-04-06', NULL, 0),
('g9GTNZBwcVB5Dyd', 'thanh do', 123, 14, 'ERF1ViJN02Y70pJ', 'dfsdfsdf', '3123dsdfsd', '2024-05-02', '2024-05-02', NULL, '2024-05-20', NULL, 80),
('ksadflsjdjlf', 'Chuyến đi Vũng Tàu', 80, 0, '0', 'Thư giãn tận hưởng bãi biển tuyệt vời tại Vũng Tàu.', 'Vũng Tàu, Bà Rịa - Vũng Tàu', '2024-04-21', '2024-04-21', 'admin', '2024-04-17', '2024-04-17', 0),
('sdfkalskdjjflk', 'Tour Vịnh Hạ Long', 100, 0, '1', 'Khám phá vẻ đẹp hùng vĩ của Vịnh Hạ Long.', 'Hạ Long, Quảng Ninh', '2024-04-20', '2024-04-20', 'admin', '2024-04-17', '2024-04-17', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `roleId` varchar(255) DEFAULT NULL,
  `account_authorize` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  `update_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `password`, `email`, `address`, `status`, `roleId`, `account_authorize`, `phone_number`, `description`, `create_at`, `update_at`) VALUES
('user1', 'tran duong', '123', 'ad@gmail.com', 'template', '1', 'userrole1', '1', '012345789', 'template', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `user_roleId` varchar(255) NOT NULL,
  `rolesId` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`user_roleId`, `rolesId`) VALUES
('userrole1', 'role1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`image_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderId`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`paymentId`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`rolesId`);

--
-- Indexes for table `tours`
--
ALTER TABLE `tours`
  ADD PRIMARY KEY (`tour_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`user_roleId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
