-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2024 at 04:20 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `travel_tour`
--

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `image_id` varchar(200) NOT NULL,
  `image_main` varchar(255) DEFAULT NULL,
  `sub_image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`image_id`, `image_main`, `sub_image`) VALUES
('0', 'pic.jpg', NULL),
('kAUEhtaIrRjTLvt', 'can_tho.jpg', NULL),
('o8DQqJpBhjOxcO4', 'Neon Sunset, Axiom Design.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderId` varchar(255) NOT NULL,
  `tourId` varchar(255) DEFAULT NULL,
  `price` double NOT NULL,
  `totalPrice` double NOT NULL,
  `name_user_order` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `create_by` varchar(200) NOT NULL,
  `time_book` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `paymentId` varchar(200) DEFAULT NULL,
  `userid` varchar(200) DEFAULT NULL,
  `orderId` varchar(200) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `time_payment` date DEFAULT current_timestamp(),
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`paymentId`, `userid`, `orderId`, `quantity`, `time_payment`, `price`) VALUES
('1', '1', '1', 12, '2024-04-06', 1000),
('2', '2', '2', 12, '2024-04-06', 1100),
('3', '3', '3', 5, '2024-04-06', 100),
('example_payment_id_21', 'example_user_id_21', 'example_order_id_21', 3, '2024-01-01', 100),
('example_payment_id_22', 'example_user_id_22', 'example_order_id_22', 5, '2024-02-15', 150),
('example_payment_id_23', 'example_user_id_23', 'example_order_id_23', 2, '2024-03-20', 80),
('example_payment_id_24', 'example_user_id_24', 'example_order_id_24', 4, '2024-04-10', 120),
('example_payment_id_25', 'example_user_id_25', 'example_order_id_25', 6, '2024-01-05', 180),
('example_payment_id_26', 'example_user_id_26', 'example_order_id_26', 7, '2024-02-12', 210),
('example_payment_id_27', 'example_user_id_27', 'example_order_id_27', 1, '2024-03-23', 50),
('example_payment_id_28', 'example_user_id_28', 'example_order_id_28', 8, '2024-04-28', 240),
('example_payment_id_29', 'example_user_id_29', 'example_order_id_29', 3, '2024-01-18', 90),
('example_payment_id_30', 'example_user_id_30', 'example_order_id_30', 2, '2024-02-29', 80),
('example_payment_id_31', 'example_user_id_31', 'example_order_id_31', 5, '2024-03-14', 150),
('example_payment_id_32', 'example_user_id_32', 'example_order_id_32', 4, '2024-04-30', 120),
('example_payment_id_33', 'example_user_id_33', 'example_order_id_33', 6, '2024-01-22', 180),
('example_payment_id_34', 'example_user_id_34', 'example_order_id_34', 3, '2024-02-09', 90),
('example_payment_id_35', 'example_user_id_35', 'example_order_id_35', 7, '2024-03-17', 210),
('example_payment_id_36', 'example_user_id_36', 'example_order_id_36', 4, '2024-04-09', 120),
('example_payment_id_37', 'example_user_id_37', 'example_order_id_37', 9, '2024-01-28', 270),
('example_payment_id_38', 'example_user_id_38', 'example_order_id_38', 2, '2024-02-21', 80),
('example_payment_id_39', 'example_user_id_39', 'example_order_id_39', 5, '2024-03-15', 150),
('example_payment_id_40', 'example_user_id_40', 'example_order_id_40', 3, '2024-04-02', 90),
('example_payment_id_41', 'example_user_id_41', 'example_order_id_41', 3, '2023-01-01', 100),
('example_payment_id_42', 'example_user_id_42', 'example_order_id_42', 5, '2023-02-15', 150),
('example_payment_id_43', 'example_user_id_43', 'example_order_id_43', 2, '2023-03-20', 80),
('example_payment_id_44', 'example_user_id_44', 'example_order_id_44', 4, '2023-04-10', 120),
('example_payment_id_45', 'example_user_id_45', 'example_order_id_45', 6, '2023-05-05', 180),
('example_payment_id_46', 'example_user_id_46', 'example_order_id_46', 7, '2023-06-12', 210),
('example_payment_id_47', 'example_user_id_47', 'example_order_id_47', 1, '2023-07-03', 50),
('example_payment_id_48', 'example_user_id_48', 'example_order_id_48', 8, '2023-08-25', 240),
('example_payment_id_49', 'example_user_id_49', 'example_order_id_49', 3, '2023-09-18', 90),
('example_payment_id_50', 'example_user_id_50', 'example_order_id_50', 2, '2023-10-29', 80),
('example_payment_id_51', 'example_user_id_51', 'example_order_id_51', 5, '2023-11-14', 150),
('example_payment_id_52', 'example_user_id_52', 'example_order_id_52', 4, '2023-12-30', 120),
('example_payment_id_53', 'example_user_id_53', 'example_order_id_53', 6, '2023-01-20', 180),
('example_payment_id_54', 'example_user_id_54', 'example_order_id_54', 3, '2023-02-08', 90),
('example_payment_id_55', 'example_user_id_55', 'example_order_id_55', 7, '2023-03-17', 210),
('example_payment_id_56', 'example_user_id_56', 'example_order_id_56', 4, '2023-04-09', 120),
('example_payment_id_57', 'example_user_id_57', 'example_order_id_57', 9, '2023-05-28', 270),
('example_payment_id_58', 'example_user_id_58', 'example_order_id_58', 2, '2023-06-21', 80),
('example_payment_id_59', 'example_user_id_59', 'example_order_id_59', 5, '2023-07-15', 150),
('example_payment_id_60', 'example_user_id_60', 'example_order_id_60', 3, '2023-08-02', 90),
('example_payment_id_61', 'example_user_id_61', 'example_order_id_61', 6, '2023-09-11', 180),
('example_payment_id_62', 'example_user_id_62', 'example_order_id_62', 3, '2023-10-01', 90),
('example_payment_id_63', 'example_user_id_63', 'example_order_id_63', 7, '2023-11-08', 210),
('example_payment_id_64', 'example_user_id_64', 'example_order_id_64', 4, '2023-12-05', 120),
('example_payment_id_65', 'example_user_id_65', 'example_order_id_65', 9, '2023-01-14', 270),
('example_payment_id_66', 'example_user_id_66', 'example_order_id_66', 2, '2023-02-21', 80),
('example_payment_id_67', 'example_user_id_67', 'example_order_id_67', 5, '2023-03-18', 150),
('example_payment_id_68', 'example_user_id_68', 'example_order_id_68', 3, '2023-04-02', 90),
('example_payment_id_69', 'example_user_id_69', 'example_order_id_69', 6, '2023-05-17', 180),
('example_payment_id_70', 'example_user_id_70', 'example_order_id_70', 3, '2023-06-25', 90),
('example_payment_id_71', 'example_user_id_71', 'example_order_id_71', 3, '2024-03-01', 100),
('example_payment_id_72', 'example_user_id_72', 'example_order_id_72', 5, '2024-03-02', 150),
('example_payment_id_73', 'example_user_id_73', 'example_order_id_73', 2, '2024-03-03', 80),
('example_payment_id_74', 'example_user_id_74', 'example_order_id_74', 4, '2024-03-04', 120),
('example_payment_id_75', 'example_user_id_75', 'example_order_id_75', 6, '2024-03-05', 180),
('example_payment_id_76', 'example_user_id_76', 'example_order_id_76', 7, '2024-03-06', 210),
('example_payment_id_77', 'example_user_id_77', 'example_order_id_77', 1, '2024-03-07', 50),
('example_payment_id_78', 'example_user_id_78', 'example_order_id_78', 8, '2024-03-08', 240),
('example_payment_id_79', 'example_user_id_79', 'example_order_id_79', 3, '2024-03-09', 90),
('example_payment_id_80', 'example_user_id_80', 'example_order_id_80', 2, '2024-03-10', 80),
('example_payment_id_81', 'example_user_id_81', 'example_order_id_81', 5, '2024-03-11', 150),
('example_payment_id_82', 'example_user_id_82', 'example_order_id_82', 4, '2024-03-12', 120),
('example_payment_id_83', 'example_user_id_83', 'example_order_id_83', 6, '2024-03-13', 180),
('example_payment_id_84', 'example_user_id_84', 'example_order_id_84', 3, '2024-03-14', 90),
('example_payment_id_85', 'example_user_id_85', 'example_order_id_85', 7, '2024-03-15', 210),
('example_payment_id_86', 'example_user_id_86', 'example_order_id_86', 4, '2024-03-16', 120),
('example_payment_id_87', 'example_user_id_87', 'example_order_id_87', 9, '2024-03-17', 270),
('example_payment_id_88', 'example_user_id_88', 'example_order_id_88', 2, '2024-03-18', 80),
('example_payment_id_89', 'example_user_id_89', 'example_order_id_89', 5, '2024-03-19', 150),
('example_payment_id_90', 'example_user_id_90', 'example_order_id_90', 3, '2024-03-20', 90),
('example_payment_id_91', 'example_user_id_91', 'example_order_id_91', 6, '2024-03-21', 180),
('example_payment_id_92', 'example_user_id_92', 'example_order_id_92', 3, '2024-03-22', 90),
('example_payment_id_93', 'example_user_id_93', 'example_order_id_93', 7, '2024-03-23', 210),
('example_payment_id_94', 'example_user_id_94', 'example_order_id_94', 4, '2024-03-24', 120),
('example_payment_id_95', 'example_user_id_95', 'example_order_id_95', 9, '2024-03-25', 270),
('example_payment_id_96', 'example_user_id_96', 'example_order_id_96', 2, '2024-03-26', 80),
('example_payment_id_97', 'example_user_id_97', 'example_order_id_97', 5, '2024-03-27', 150),
('example_payment_id_98', 'example_user_id_98', 'example_order_id_98', 3, '2024-03-28', 90),
('example_payment_id_99', 'example_user_id_99', 'example_order_id_99', 6, '2024-03-29', 180),
('example_payment_id_100', 'example_user_id_100', 'example_order_id_100', 3, '2024-03-30', 90);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `rolesId` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`rolesId`, `name`, `status`) VALUES
('role1', 'all', '1');

-- --------------------------------------------------------

--
-- Table structure for table `time_book_details`
--

CREATE TABLE `time_book_details` (
  `time_id` varchar(255) DEFAULT NULL,
  `tuor_id` varchar(255) DEFAULT NULL,
  `start_time` varchar(255) DEFAULT NULL,
  `end_time` varchar(255) DEFAULT NULL,
  `is_payment` varchar(255) DEFAULT NULL,
  `is_deleted` varchar(255) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  `update_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tours`
--

CREATE TABLE `tours` (
  `tour_id` varchar(200) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `price_one_person` double DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `image_id` varchar(50) DEFAULT NULL,
  `destination_description` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `time_book_start` date DEFAULT current_timestamp(),
  `time_book_end` date DEFAULT NULL,
  `create_by` varchar(50) DEFAULT NULL,
  `create_at` date DEFAULT current_timestamp(),
  `update_at` date DEFAULT NULL,
  `expense` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tours`
--

INSERT INTO `tours` (`tour_id`, `title`, `price_one_person`, `quantity`, `image_id`, `destination_description`, `address`, `time_book_start`, `time_book_end`, `create_by`, `create_at`, `update_at`, `expense`) VALUES
('7RiDW5ryjuCnddF', 'tour   them moi 1', 100, 1, 'o8DQqJpBhjOxcO4', 'hoa cai do', 'hai  phong', '2024-04-16', '2024-04-16', NULL, '2024-04-22', NULL, 80),
('asdflsjdlfs', 'Tour Phiêu Lưu Đà Lạt', 120, 10, '0', 'Tham gia vào các hoạt động mạo hiểm ở Đà Lạt.', 'Đà Lạt, Lâm Đồng', '2024-04-22', '2024-04-22', 'admin', '2024-04-17', '2024-04-17', 0),
('asldfjlsdjf', 'Trải Nghiệm Di Sản Huế', 90, 0, '0', 'Khám phá lịch sử và văn hóa phong phú của Huế.', 'Huế, Thừa Thiên-Huế', '2024-04-23', '2024-04-23', 'admin', '2024-04-17', '2024-04-17', 0),
('asldfjlsdjj', 'Khám Phá Thiên Nhiên Quảng Ninh', 110, 0, '0', 'Khám phá những kỳ quan thiên nhiên của tỉnh Quảng Ninh.', 'Quảng Ninh, Việt Nam', '2024-04-24', '2024-04-24', 'admin', '2024-04-17', '2024-04-17', 0),
('ewjrmldfjsldfls', 'vịnh hạ long', 1000, 0, '1', 'template', 'quảng ninh', '2024-04-06', NULL, 'root', '2024-04-06', NULL, 0),
('GDILWxdebz0OY4A', 'gio', 100, 0, 'kAUEhtaIrRjTLvt', 'dfgdfgdfgd', 'sdfasdfsadfsa', '2024-04-09', '2024-04-09', NULL, '2024-04-22', NULL, 80),
('ksadflsjdjlf', 'Chuyến đi Vũng Tàu', 80, 0, '0', 'Thư giãn tận hưởng bãi biển tuyệt vời tại Vũng Tàu.', 'Vũng Tàu, Bà Rịa - Vũng Tàu', '2024-04-21', '2024-04-21', 'admin', '2024-04-17', '2024-04-17', 0),
('sdfkalskdjjflk', 'Tour Vịnh Hạ Long', 100, 0, '1', 'Khám phá vẻ đẹp hùng vĩ của Vịnh Hạ Long.', 'Hạ Long, Quảng Ninh', '2024-04-20', '2024-04-20', 'admin', '2024-04-17', '2024-04-17', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `roleId` varchar(255) DEFAULT NULL,
  `account_authorize` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  `update_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `password`, `email`, `address`, `status`, `roleId`, `account_authorize`, `phone_number`, `description`, `create_at`, `update_at`) VALUES
('user1', 'tran duong', '123', 'ad@gmail.com', 'template', '1', 'userrole1', '1', '012345789', 'template', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `user_roleId` varchar(255) NOT NULL,
  `rolesId` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`user_roleId`, `rolesId`) VALUES
('userrole1', 'role1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`image_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderId`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`rolesId`);

--
-- Indexes for table `tours`
--
ALTER TABLE `tours`
  ADD PRIMARY KEY (`tour_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`user_roleId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
